"""Regenerate the standalone GitHub Pages page from original source files."""
from pathlib import Path
import base64
root = Path(__file__).resolve().parent
source = root / "src"
html = (source / "index.html").read_text()
css = (source / "assets/styles.css").read_text()
html = html.replace('<link rel="stylesheet" href="assets/styles.css">', '<style>\n'+css+'\n</style>')
html = html.replace('  <script defer src="assets/model.js"></script>\n  <script defer src="assets/app.js"></script>', '')
favicon = base64.b64encode((source / "assets/favicon.svg").read_bytes()).decode()
html = html.replace('href="assets/favicon.svg"', 'href="data:image/svg+xml;base64,'+favicon+'"')
html = html.replace('href="README.md" target="_blank" rel="noopener" id="repository-link">项目说明 ↗', 'href="https://github.com/alan99840/accu-decu-academy" target="_blank" rel="noopener" id="repository-link">GitHub 源码 ↗')
scripts = "\n".join((source / p).read_text() for p in ["assets/model.js", "assets/app.js"])
html = html.replace('</body>', '<script>\n'+scripts+'\n</script>\n</body>')
(root / "index.html").write_text(html)
print("Generated index.html")
