const assert = require('node:assert/strict');
const {calculate, scenarios} = require('../src/assets/model.js');

// Known obligations from the worked classroom examples, independently calculated.
for (const product of ['accu','decu']) {
  const adverse=calculate({product,scenario:'adverse',gearing:2});
  assert.equal(adverse.quantity,1700);
  assert.equal(adverse.cash,product==='accu'?153000:187000);
  assert.equal(adverse.pnl,-34000);
  assert.equal(adverse.cashPnl,-14800);
  assert.equal(adverse.koDay,null);
  const plain=calculate({product,scenario:'adverse',gearing:1});
  assert.equal(plain.quantity,1000);
  assert.equal(plain.pnl,-20000);
  const ko=calculate({product,scenario:'ko',gearing:2});
  assert.equal(ko.koDay,4);
  assert.equal(ko.quantity,300);
  assert.equal(ko.pnl,7500);
  assert.equal(ko.cashPnl,3400);
  assert.equal(ko.rows[3].shares,0);
  assert.equal(ko.batches[0].quantity,300);
  assert.equal(ko.batches[1].quantity,0);
  const a=calculate({product,scenario:'same-a',gearing:2});
  const b=calculate({product,scenario:'same-b',gearing:2});
  assert.equal(a.finalPrice,b.finalPrice);
  assert.equal(a.quantity,1000);assert.equal(b.quantity,1300);
  assert.equal(a.pnl,10000);assert.equal(b.pnl,13000);
  assert.equal(a.cashPnl,10000);assert.equal(b.cashPnl,2400);
  const equalStrike=calculate({product,scenario:'rebound',gearing:2});
  assert.equal(equalStrike.rows[1].price,equalStrike.strike);
  assert.equal(equalStrike.rows[1].shares,100);
  for(const scenario of scenarios) for(const gearing of [1,2]) {
    const m=calculate({product,scenario,gearing});
    assert.equal(m.batches.reduce((s,b)=>s+b.quantity,0),m.quantity);
    assert.equal(m.batches.reduce((s,b)=>s+b.cash,0),m.cash);
    assert.equal(m.batches.reduce((s,b)=>s+b.cashDifference,0),m.cashPnl);
    assert.ok(m.rows.every(r=>r.shares===0||r.shares===100||r.shares===200));
  }
}
console.log('Passed: 24 product/path/gearing combinations; KO, exact-strike, settlement and path-dependence examples.');
