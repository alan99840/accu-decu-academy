/* MIT License. Pure teaching model; prices and terms are hypothetical. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.AccuDecuModel = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const paths = {
    accu: {
      range: [100,98,97,96,99,100,102,101,103,100],
      adverse: [98,95,91,89,85,80,78,75,72,70],
      ko: [100,101,103,106,108,110,112,113,114,115],
      rebound: [98,90,85,80,85,92,96,100,102,100],
      'same-a': [100,100,100,100,100,100,100,100,100,100],
      'same-b': [100,85,82,100,100,80,100,100,100,100]
    },
    decu: {
      range: [100,102,103,104,101,100,98,99,97,100],
      adverse: [102,105,109,111,115,120,122,125,128,130],
      ko: [100,99,97,94,92,90,88,87,86,85],
      rebound: [102,110,115,120,115,108,104,100,98,100],
      'same-a': [100,100,100,100,100,100,100,100,100,100],
      'same-b': [100,115,118,100,100,120,100,100,100,100]
    }
  };
  function calculate(input) {
    const product = input.product === 'decu' ? 'decu' : 'accu';
    const scenario = Object.prototype.hasOwnProperty.call(paths[product], input.scenario) ? input.scenario : 'range';
    const gearing = Number(input.gearing) === 1 ? 1 : 2;
    const accu = product === 'accu';
    const strike = accu ? 90 : 110;
    const barrier = accu ? 105 : 95;
    let koDay = null;
    let cumulative = 0;
    const rows = paths[product][scenario].map((price, index) => {
      const day = index + 1;
      const hit = accu ? price >= barrier : price <= barrier;
      if (koDay === null && hit) koDay = day;
      const adverse = accu ? price < strike : price > strike;
      const shares = koDay === null ? 100 * (adverse ? gearing : 1) : 0;
      cumulative += shares;
      const cash = shares * strike;
      const cashDifference = shares * (accu ? price - strike : strike - price);
      const status = day === koDay ? '觸發 KO' : koDay !== null ? 'KO 後停止' : adverse && gearing === 2 ? '不利 · 2x' : '正常 · 1x';
      return {day, price, shares, cash, cashDifference, cumulative, adverse: adverse && shares > 0, status};
    });
    const quantity = cumulative;
    const cash = quantity * strike;
    const finalPrice = rows[rows.length - 1].price;
    const pnl = accu ? quantity * finalPrice - cash : cash - quantity * finalPrice;
    const cashPnl = rows.reduce((sum, row) => sum + row.cashDifference, 0);
    const batches = [5, 10].map(day => {
      const batch = rows.slice(day - 5, day);
      return {day, quantity: batch.reduce((s,r) => s+r.shares,0), cash: batch.reduce((s,r) => s+r.cash,0), cashDifference: batch.reduce((s,r) => s+r.cashDifference,0)};
    });
    return {product, scenario, gearing, accu, strike, barrier, rows, quantity, cash, finalPrice, pnl, cashPnl, koDay, batches};
  }
  return {calculate, scenarios: Object.keys(paths.accu)};
});
