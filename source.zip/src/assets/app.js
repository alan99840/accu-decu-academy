/* MIT License — no external libraries, tracking, or network data requests. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const simulator = $('accu-decu-classroom');
  const storageKey = 'accu-decu-academy-v1';
  const defaults = {product:'accu', scenario:'range', gearing:2, settlement:'physical', checks:[]};
  let state = {...defaults};
  try {
    const saved = JSON.parse(localStorage.getItem(storageKey));
    if (saved && typeof saved === 'object') {
      if (['accu','decu'].includes(saved.product)) state.product = saved.product;
      if (AccuDecuModel.scenarios.includes(saved.scenario)) state.scenario = saved.scenario;
      if ([1,2].includes(saved.gearing)) state.gearing = saved.gearing;
      if (['physical','cash'].includes(saved.settlement)) state.settlement = saved.settlement;
      if (Array.isArray(saved.checks)) state.checks = saved.checks.filter(v=>typeof v==='string');
    }
  } catch (_) { /* Browsing still works when storage is unavailable. */ }
  function save() { try { localStorage.setItem(storageKey, JSON.stringify(state)); } catch (_) {} }
  const number = v => Math.abs(v).toLocaleString('en-US');
  const money = (v, signed = false) => (v < 0 ? '−' : signed && v > 0 ? '+' : '') + 'HK$ ' + number(v);
  let model;
  let inspectedDay = 1;
  let chartSize;
  const NS = 'http://www.w3.org/2000/svg';
  function svgNode(tag, attrs, text) {
    const el = document.createElementNS(NS, tag);
    Object.entries(attrs || {}).forEach(([key,value]) => el.setAttribute(key, String(value)));
    if (text !== undefined) el.textContent = text;
    return el;
  }
  function add(svg, tag, attrs, text) { const el = svgNode(tag,attrs,text); svg.appendChild(el); return el; }
  function plotCharts() {
    const m = model;
    const price = $('price-chart'), quantity = $('quantity-chart');
    const width = Math.max(245, price.getBoundingClientRect().width);
    const narrow = width < 450;
    const ph = narrow ? 225 : 252, qh = narrow ? 141 : 157;
    const left = narrow ? 38 : 47, right = 22, top = 33, bottom = 31;
    const x = day => left + 12 + (day-1) * (width-left-right-24) / 9;
    const values = [...m.rows.map(r=>r.price),m.strike,m.barrier];
    const min = Math.floor((Math.min(...values)-8)/5)*5;
    const max = Math.ceil((Math.max(...values)+8)/5)*5;
    const y = value => ph-bottom-(value-min)/(max-min)*(ph-top-bottom);
    const qy = value => qh-bottom-value/240*(qh-top-bottom);
    chartSize = {width, ph, qh, x, y, qy, left, right, top, bottom};
    price.replaceChildren(); quantity.replaceChildren();
    price.setAttribute('viewBox',`0 0 ${width} ${ph}`); price.setAttribute('height',ph);
    quantity.setAttribute('viewBox',`0 0 ${width} ${qh}`); quantity.setAttribute('height',qh);
    price.setAttribute('aria-label',`10 個觀察日的股價路徑；執行價 ${m.strike}，KO ${m.barrier}。${m.koDay ? '第 '+m.koDay+' 日敲出。' : '沒有敲出。'} 可透過下方滑桿或逐日表讀取資料。`);
    quantity.setAttribute('aria-label',`每日${m.accu?'買入':'賣出'}義務共 ${m.quantity} 股；${m.rows.map(r=>'第'+r.day+'日 '+r.shares+'股').join('，')}`);
    add(price,'title',{},'股價與執行價 / KO 障礙價'); add(quantity,'title',{},'每日股數');
    for (let i=0;i<=4;i++) {
      const value = min+(max-min)*i/4;
      add(price,'line',{x1:left,x2:width-right,y1:y(value),y2:y(value),stroke:'var(--line)','stroke-opacity':.65});
      add(price,'text',{x:left-8,y:y(value)+3,'text-anchor':'end',class:'chart-tick'},String(Math.round(value)));
    }
    [0,100,200].forEach(v=>{
      add(quantity,'line',{x1:left,x2:width-right,y1:qy(v),y2:qy(v),stroke:'var(--line)','stroke-opacity':.65});
      add(quantity,'text',{x:left-8,y:qy(v)+3,'text-anchor':'end',class:'chart-tick'},String(v));
    });
    const tickDays = narrow ? [1,4,7,10] : m.rows.map(r=>r.day);
    tickDays.forEach(day=>{
      add(price,'text',{x:x(day),y:ph-10,'text-anchor':'middle',class:'chart-tick'},'D'+String(day).padStart(2,'0'));
      add(quantity,'text',{x:x(day),y:qh-10,'text-anchor':'middle',class:'chart-tick'},'D'+String(day).padStart(2,'0'));
    });
    [{value:m.strike,name:'K',color:'var(--brand-green)',dash:'5 4'},{value:m.barrier,name:'KO',color:'var(--green)',dash:'2 4'}].forEach(ref=>{
      add(price,'line',{x1:left,x2:width-right,y1:y(ref.value),y2:y(ref.value),stroke:ref.color,'stroke-width':1,'stroke-dasharray':ref.dash,'stroke-opacity':.7});
      add(price,'text',{x:left+5,y:y(ref.value)-6,fill:ref.color,style:`fill:${ref.color}`,class:'reference-label'},`${ref.name} ${ref.value}`);
    });
    const line = rows => rows.map((r,i)=>(i?'L':'M')+x(r.day).toFixed(2)+','+y(r.price).toFixed(2)).join(' ');
    if (m.koDay) {
      add(price,'path',{d:line(m.rows.slice(m.koDay-1)),fill:'none',stroke:'var(--muted)','stroke-width':1.5,'stroke-dasharray':'4 4','stroke-opacity':.45});
      add(price,'line',{x1:x(m.koDay),x2:x(m.koDay),y1:top-7,y2:ph-bottom,stroke:'var(--green)','stroke-dasharray':'2 5','stroke-opacity':.5});
      add(price,'text',{x:x(m.koDay)+6,y:18,style:'fill:var(--green)',class:'reference-label'},'D'+String(m.koDay).padStart(2,'0')+' KO');
    }
    add(price,'path',{d:line(m.koDay ? m.rows.slice(0,m.koDay) : m.rows),fill:'none',stroke:'var(--brand-red)','stroke-width':2.3,'stroke-linejoin':'round','stroke-linecap':'round'});
    const bw = Math.min(28,(width-left-right)/15);
    m.rows.forEach(r=>{
      add(price,'circle',{cx:x(r.day),cy:y(r.price),r:3,fill:m.koDay&&r.day>m.koDay?'var(--muted)':'var(--brand-red)','fill-opacity':m.koDay && r.day > m.koDay ? 0.4 : 1});
      const hit = add(price,'circle',{cx:x(r.day),cy:y(r.price),r:12,fill:'transparent','data-day':r.day,class:'chart-point'});
      hit.appendChild(svgNode('title',{},`第 ${r.day} 日：股價 ${r.price}，${r.shares} 股，${r.status}`));
      add(quantity,'rect',{x:x(r.day)-bw/2,y:qy(r.shares),width:bw,height:qy(0)-qy(r.shares),fill:'var(--brand-red)','fill-opacity':r.shares>100?1:.45,'data-day':r.day,class:'chart-point'});
      if (!narrow || tickDays.includes(r.day)) add(quantity,'text',{x:x(r.day),y:qy(r.shares)-7,'text-anchor':'middle',style:r.shares>100?'fill:var(--brand-red)':''},String(r.shares));
    });
    add(price,'line',{id:'inspect-guide',x1:x(inspectedDay),x2:x(inspectedDay),y1:top,y2:ph-bottom,stroke:'var(--text)','stroke-dasharray':'2 3','stroke-opacity':.35});
    add(price,'circle',{id:'inspect-marker',cx:x(inspectedDay),cy:y(m.rows[inspectedDay-1].price),r:5,class:'focus-circle','pointer-events':'none'});
    inspect(inspectedDay);
  }
  function inspect(day) {
    inspectedDay = Math.max(1,Math.min(10,Number(day)));
    const r = model.rows[inspectedDay-1];
    $('inspect-day').value = inspectedDay;
    $('day-output').textContent = 'D'+String(inspectedDay).padStart(2,'0');
    $('day-detail').replaceChildren();
    const detail = $('day-detail');
    detail.append('股價 '); const p=document.createElement('strong');p.textContent=r.price;detail.append(p,' · ');
    const q=document.createElement('strong');q.textContent=r.shares+' 股';detail.append(q,' · '+r.status);
    if (chartSize && $('inspect-guide')) {
      const x=chartSize.x(inspectedDay);
      $('inspect-guide').setAttribute('x1',x);$('inspect-guide').setAttribute('x2',x);
      $('inspect-marker').setAttribute('cx',x);$('inspect-marker').setAttribute('cy',chartSize.y(r.price));
    }
  }
  function render() {
    model=AccuDecuModel.calculate(state);
    const m=model, cashMode=state.settlement==='cash';
    simulator.classList.toggle('decu',!m.accu);
    document.querySelectorAll('[data-product]').forEach(button=>{
      const selected=button.dataset.product===state.product;
      button.classList.toggle('selected',selected);button.setAttribute('aria-pressed',String(selected));
    });
    $('scenario').value=state.scenario;$('gearing').value=state.gearing;$('settlement-mode').value=state.settlement;
    $('sim-terms').innerHTML=`<span>期初 <b>100</b></span><span>執行價 <b>${m.strike}</b></span><span>KO <b>${m.barrier}</b></span><span>基礎 <b>100 股/日</b></span><span>幣種 <b>HKD</b></span>`;
    $('quantity-chart-title').innerHTML=`02 / 每日${m.accu?'買入':'賣出'}義務 <span class="chart-unit">SHARES</span>`;
    $('quantity-label').textContent=cashMode?'累計等價股數':m.accu?'累計買股':'累計賣股／交付';
    $('total-quantity').textContent=number(m.quantity)+' 股';
    $('quantity-description').textContent=cashMode?'用於計算差額，不交付股票':'按合約累計的實物義務';
    $('cash-label').textContent=cashMode?'淨現金結算':m.accu?'累計購股價款':'累計賣股收入';
    $('total-cash').textContent=cashMode?money(m.cashPnl,true):money(m.cash);
    $('total-cash').classList.toggle('negative',cashMode&&m.cashPnl<0);
    $('total-cash').classList.toggle('positive',cashMode&&m.cashPnl>0);
    $('cash-description').textContent=cashMode?(m.cashPnl<0?'客戶淨付款':m.cashPnl>0?'客戶淨收款':'淨差額為零'):'股數 × 執行價';
    $('pnl-label').textContent=cashMode?'本合約結算新增持股':m.accu?'期末股票浮動損益':'相對期末賣股的差額';
    const pnl=cashMode?m.cashPnl:m.pnl;
    $('total-pnl').textContent=cashMode?'0 股':money(pnl,true);$('total-pnl').className='mono '+(!cashMode&&pnl<0?'negative':!cashMode&&pnl>0?'positive':'');
    $('pnl-description').textContent=cashMode?'現金差額結算不交付股票':m.accu?'已買股數 × 期末價 − 價款':'賣股收入 − 已賣股數 × 期末價';
    $('sim-status').innerHTML=m.koDay?`<b>第 ${m.koDay} 日 KO。</b> 當日及之後不再計量，此前 ${number(m.quantity)} 股的${cashMode?'等價差額義務':'買賣義務'}仍按原定批次結算。虛線顯示 KO 後的標的走勢。`:'<b>沒有 KO。</b> 持續到第 10 日；第 5、10 日按各批次累計義務結算。';
    if (m.koDay && !cashMode && m.accu) $('sim-status').append(' 已取得股票在 KO 後仍繼續隨市價漲跌。');
    const comparison=$('path-lesson');comparison.hidden=!state.scenario.startsWith('same-');
    if (!comparison.hidden) {
      const a=AccuDecuModel.calculate({...state,scenario:'same-a'}),b=AccuDecuModel.calculate({...state,scenario:'same-b'});
      comparison.textContent=cashMode?`同樣終價 100：A 累計 ${number(a.quantity)} 股等價義務、淨差額 ${money(a.cashPnl,true)}；B 累計 ${number(b.quantity)} 股、淨差額 ${money(b.cashPnl,true)}。現金差額既取決於股數，也取決於每個觀察日的參考價。`:`同樣終價 100：A 累計 ${number(a.quantity)} 股，B 累計 ${number(b.quantity)} 股。中途越過執行價會改變累計數量；在這條最終回到 100 的路徑上，更多數量也可能使期末結果更高，不能據此推斷加倍總是有利。`;
    }
    $('ledger-cash-heading').textContent=cashMode?'現金差額 HK$':'約定價款 HK$';
    $('daily-ledger').replaceChildren();
    m.rows.forEach(row=>{
      const tr=document.createElement('tr');
      ['D'+String(row.day).padStart(2,'0'),row.price,row.status,number(row.shares),cashMode?(row.cashDifference<0?'−':row.cashDifference>0?'+':'')+number(row.cashDifference):number(row.cash)].forEach((value,i)=>{
        const td=document.createElement('td');td.textContent=value;
        if (i===2 && row.status.includes('KO')) td.className='brand-green';
        if (i===3 && row.shares>100) td.className='brand-red';
        if (i===4&&cashMode&&row.cashDifference<0) td.className='negative';
        tr.append(td);
      });
      $('daily-ledger').append(tr);
    });
    $('ledger-total').innerHTML=`<tr><th colspan="3">合計</th><td>${number(m.quantity)}</td><td>${cashMode?(m.cashPnl<0?'−':m.cashPnl>0?'+':'')+number(m.cashPnl):number(m.cash)}</td></tr>`;
    $('settlement-batches').innerHTML=m.batches.map(batch=>`<div>D${String(batch.day).padStart(2,'0')} 交割 / 第 ${batch.day-4}—${batch.day} 日義務<b>${cashMode?money(batch.cashDifference,true):number(batch.quantity)+' 股 · '+money(batch.cash)}</b></div>`).join('');
    simulator.dataset.quantity=String(m.quantity);simulator.dataset.cash=String(m.cash);simulator.dataset.pnl=String(pnl);simulator.dataset.koDay=String(m.koDay||0);
    plotCharts();save();
  }
  document.querySelectorAll('[data-product]').forEach(button=>button.addEventListener('click',()=>{state.product=button.dataset.product;render();}));
  $('scenario').addEventListener('change',e=>{state.scenario=e.target.value;render();});
  $('gearing').addEventListener('change',e=>{state.gearing=Number(e.target.value);render();});
  $('settlement-mode').addEventListener('change',e=>{state.settlement=e.target.value;render();});
  $('inspect-day').addEventListener('input',e=>inspect(e.target.value));
  ['price-chart','quantity-chart'].forEach(id=>{
    $(id).addEventListener('click',event=>{
      const point=event.target.closest('[data-day]');
      if(point) inspect(point.dataset.day);
      else if(chartSize) {
        const rect=$(id).getBoundingClientRect(),px=(event.clientX-rect.left)/rect.width*chartSize.width;
        const day=Math.round(1+(px-chartSize.x(1))/(chartSize.x(10)-chartSize.x(1))*9);inspect(day);
      }
    });
  });
  $('download-csv').addEventListener('click',()=>{
    const csv=['產品,情境,結算假設,觀察日,股價_HKD,股數,狀態,約定價款_HKD,客戶現金差額_HKD',...model.rows.map(r=>[state.product,state.scenario,state.settlement,r.day,r.price,r.shares,r.status,r.cash,r.cashDifference].join(',')),'','教學假設：收盤觀察；KO 當日不計量；無 KI；無保證期；不計費用；現金按各觀察日價定價。'].join('\r\n');
    const url=URL.createObjectURL(new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8'}));
    const a=document.createElement('a');a.href=url;a.download=`${state.product}-${state.scenario}-${state.settlement}.csv`;a.click();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
  });
  let resizeFrame;
  new ResizeObserver(()=>{cancelAnimationFrame(resizeFrame);resizeFrame=requestAnimationFrame(plotCharts);}).observe($('price-chart').parentElement);

  const checklist=[...document.querySelectorAll('[data-check]')];
  function updateChecklist(){state.checks=checklist.filter(c=>c.checked).map(c=>c.dataset.check);$('checklist-progress').textContent=`已核對 ${state.checks.length} / 8 項`;save();}
  checklist.forEach(c=>{c.checked=state.checks.includes(c.dataset.check);c.addEventListener('change',updateChecklist);});
  $('reset-checklist').addEventListener('click',()=>{checklist.forEach(c=>c.checked=false);updateChecklist();});updateChecklist();
  const feedback={ko:'KO 處理後續部分；之前累計的義務不會自動消失。',margin:'保證金擔保履約。全部價款、追加擔保品及極端損失須另算。',note:'Note 是法律形式，OTC 是交易場所，兩者可以同時成立。'};
  document.querySelectorAll('.quiz').forEach(quiz=>quiz.querySelectorAll('button').forEach(button=>button.addEventListener('click',()=>{
    quiz.querySelectorAll('button').forEach(b=>{b.classList.remove('chosen-correct','chosen-wrong');b.setAttribute('aria-pressed','false');});
    const correct=button.dataset.answer==='correct';button.classList.add(correct?'chosen-correct':'chosen-wrong');button.setAttribute('aria-pressed','true');
    quiz.querySelector('.quiz-feedback').textContent=(correct?'答對了。':'再想一想。')+feedback[quiz.dataset.quiz];
  })));
  const menu=$('menu-button'),nav=$('course-nav');
  function closeMenu(){nav.classList.remove('open');menu.setAttribute('aria-expanded','false');}
  menu.addEventListener('click',()=>{const open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(open));});
  nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',closeMenu));
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu();});
  document.addEventListener('click',e=>{if(!nav.contains(e.target)&&!menu.contains(e.target))closeMenu();});
  $('print-button').addEventListener('click',()=>window.print());
  const navLinks=[...document.querySelectorAll('.nav-item')];
  let scrollFrame;
  function updateReading(){
    const height=document.documentElement.scrollHeight-innerHeight;
    $('reading-progress').style.width=(height>0?Math.min(100,scrollY/height*100):0)+'%';
    let current='concept';
    navLinks.forEach(link=>{if(document.querySelector(link.hash).getBoundingClientRect().top<=150)current=link.hash.slice(1);});
    navLinks.forEach(link=>{const active=link.hash==='#'+current;link.classList.toggle('active',active);if(active)link.setAttribute('aria-current','location');else link.removeAttribute('aria-current');});
  }
  window.addEventListener('scroll',()=>{cancelAnimationFrame(scrollFrame);scrollFrame=requestAnimationFrame(updateReading);},{passive:true});
  render();updateReading();
})();
